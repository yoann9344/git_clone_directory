use web::*;

#[no_mangle]
pub fn main() {
    log("Hey");
}

