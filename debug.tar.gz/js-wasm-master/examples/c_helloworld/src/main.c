#include "../../headers/web_console.h"

export int main() {
	console_log("hello");
	console_log("world");
	return 0;
}