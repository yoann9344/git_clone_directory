import {console_log} from "../../../assemblyscript/web_console"

export function main():void {
  console_log("hello");
  console_log("world");
}
